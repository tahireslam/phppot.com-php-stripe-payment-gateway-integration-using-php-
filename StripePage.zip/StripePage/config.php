<?php 
define("STRIPE_SECRET_KEY", "sk_test_J4V2f5WxYwn0y1L7PZxlPLrA00sM2yNqu0");
define("STRIPE_PUBLISHABLE_KEY", "pk_test_t10nVWrY8tHKErfr6WFDcSDr00NARKPDsN");
?>